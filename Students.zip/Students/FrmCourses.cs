﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Students
{
    public partial class FrmCourses : Form
    {
        public FrmCourses()
        {
            InitializeComponent();
        }

        public void ClearAll()
        {
            txtCID.Clear();
            txtCName.Clear();
            txtCCH.Clear();
            txtCDur.Clear();
            txtCFee.Clear();
        }
       
        public void LoadData()
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=SDM;Integrated Security=True");
            SqlDataAdapter sda = new SqlDataAdapter("SelectCourse", con);
            sda.SelectCommand.CommandType = CommandType.StoredProcedure;

            DataSet ds = new DataSet();
            sda.Fill(ds, "a");
            DGVCourse.DataSource = ds.Tables["a"];
            
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        
        private void FrmCourses_Load(object sender, EventArgs e)
        {
            LoadData();
           // ClearAll();
        }
        private bool IfCourseExist(SqlConnection con, string CorID)
        {
            SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM [dbo].[Course] WHERE [CID] = '" + CorID + "'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
                return true;
            else
                return false;
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=SDM;Integrated Security=True");
            con.Open();
            var sqlQuery = "";
            if (IfCourseExist(con, txtCID.Text))
            {
                sqlQuery = @"DELETE FROM [Course] WHERE [CID] = '" + txtCID.Text + "'";
                SqlCommand cmd = new SqlCommand(sqlQuery, con);
                cmd.ExecuteNonQuery();
                con.Close();
                ClearAll();
                LoadData();
            }
            else
            {
                MessageBox.Show("Record not Exist!!!!");
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=SDM;Integrated Security=True");
            con.Open();
            var sqlQuery = "";
            if (IfCourseExist(con, txtCID.Text))
            {
                sqlQuery = @"UPDATE [Course] SET [CTitle] = '" + txtCName.Text + "',Duration = '" + txtCDur.Text + "',CreditHr = '" + txtCCH.Text + "',Fee='" + txtCFee.Text + "'WHERE [CID] = '" + txtCID.Text + "'";
            }
            else
            {
                sqlQuery = @"INSERT INTO [dbo].[Course]([CID],[CTitle],[Duration],[CreditHr],[Fee]) VALUES ('" + txtCID.Text + "','" + txtCName.Text + "','" + txtCCH.Text + "','" + txtCDur.Text + "','" + txtCFee.Text + "')";
            }

            SqlCommand cmd = new SqlCommand(sqlQuery, con);
            cmd.ExecuteNonQuery();
            con.Close();
            LoadData();
            ClearAll();
        }

        private void DGVCourse_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void DGVCourse_MouseClick(object sender, MouseEventArgs e)
        {
            txtCID.Text = DGVCourse.SelectedRows[0].Cells[0].Value.ToString();
            txtCName.Text = DGVCourse.SelectedRows[0].Cells[1].Value.ToString();
            txtCCH.Text = DGVCourse.SelectedRows[0].Cells[2].Value.ToString();
            txtCDur.Text = DGVCourse.SelectedRows[0].Cells[3].Value.ToString();
            txtCFee.Text = DGVCourse.SelectedRows[0].Cells[4].Value.ToString();
           
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
        public void Display()
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=SDM;Integrated Security=True");
            DataTable dt = new DataTable();
            if (txtCourseID.Text.Length > 0)
            {
                SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM Course WHERE CID LIKE '" + txtCourseID.Text + "%'", con);
                sda.Fill(dt);
            }
            else if (txtCourseTitle.Text.Length > 0)
            {
                SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM Course WHERE CTitle LIKE '" + txtCourseTitle.Text + "%'", con);
                sda.Fill(dt);
            }
            DGVCourse.DataSource = dt;
        }

        private void txtCourseID_TextChanged(object sender, EventArgs e)
        {
            txtCourseTitle.Text = "";
            if (txtCourseID.Text.Length > 0)
            {
                Display();
            }
            else
            {
                LoadData();
            }
        }

        private void txtCourseTitle_TextChanged(object sender, EventArgs e)
        {
            txtCourseID.Text = "";
            if (txtCourseTitle.Text.Length > 0)
            {
                Display();
            }
            else
            {
                LoadData();
            }
        }

        

    }
}
