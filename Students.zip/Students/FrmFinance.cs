﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Students
{
    public partial class FrmFinance : Form
    {
        public FrmFinance()
        {
            InitializeComponent();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        public void ClearAll()
        {
            txtStdID.Clear();
            txtDues.Clear();
            txtCell.Clear();
            txtRemainDues.Clear();
            txtDefaulter.Clear();
            txtDOS.Clear();
        }
        public void LoadData()
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=SDM;Integrated Security=True");
            SqlDataAdapter sda = new SqlDataAdapter("SelectStud", con);
            sda.SelectCommand.CommandType = CommandType.StoredProcedure;

            DataSet ds = new DataSet();
            sda.Fill(ds, "a");
            DGVFinance.DataSource = ds.Tables["a"];

        }

        private void DGVFinance_MouseClick(object sender, MouseEventArgs e)
        {
            txtStdID.Text = DGVFinance.SelectedRows[0].Cells[0].Value.ToString();
            txtCell.Text = DGVFinance.SelectedRows[0].Cells[1].Value.ToString();
            txtDues.Text = DGVFinance.SelectedRows[0].Cells[2].Value.ToString();
            txtDefaulter.Text = DGVFinance.SelectedRows[0].Cells[3].Value.ToString();
            txtDOS.Text = DGVFinance.SelectedRows[0].Cells[4].Value.ToString();
            txtRemainDues.Text = DGVFinance.SelectedRows[0].Cells[5].Value.ToString();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=SDM;Integrated Security=True");
            con.Open();
            var sqlQuery = "";
            if (IfStudExist(con, txtStdID.Text))
            {
                sqlQuery= @"UPDATE [Faculty] SET [Cell#] = '" + txtCell.Text + "',Fee = '" + txtDues.Text + "'Defaulter = '" + txtDefaulter.Text + "',DOSubmission='" + txtDOS.Text + "',PendingAmount = '" + txtRemainDues.Text + "'WHERE [StdID] = '" + txtStdID + "'";
            }
            else
            {
                sqlQuery = @"INSERT INTO [dbo].[Finance]([StdID],[Cell#],[Fee],[Defaulter],[DOSubmission],[PendingAmount]) VALUES ('" + txtStdID.Text + "','" + txtCell.Text + "','" + txtDues.Text + "','" + txtDefaulter.Text + "','" + txtDOS.Text + "','" + txtRemainDues.Text + "')";
            }

            SqlCommand cmd = new SqlCommand(sqlQuery, con);
            cmd.ExecuteNonQuery();
            con.Close();
            LoadData();
            ClearAll();
        }
        private bool IfStudExist(SqlConnection con, string DefaultID)
        {
            SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM [dbo].[Finance] WHERE [StdID] = '" + DefaultID + "'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
                return true;
            else
                return false;
        }

        private void FrmFinance_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=SDM;Integrated Security=True");
            con.Open();
            var sqlQuery = "";
            if (IfStudExist(con, txtStdID.Text))
            {
                sqlQuery = @"UPDATE [Finance] SET [Cell#] = '" + txtCell.Text + "',Fee = '" + txtDues.Text + "'Defaulter = '" + txtDefaulter.Text + "',DOSubmission='" + txtDOS.Text + "',PendingAmount = '" + txtRemainDues.Text + "'WHERE [StdID] = '" + txtStdID + "'";
            }
            else
            {
                
            }

            SqlCommand cmd = new SqlCommand(sqlQuery, con);
            cmd.ExecuteNonQuery();
            con.Close();
            LoadData();
            ClearAll();
        }

        private void DGVFinance_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=SDM;Integrated Security=True");
            con.Open();
            var sqlQuery = "";
            if (IfStudExist(con, txtStdID.Text))
            {
                sqlQuery = @"DELETE FROM [Finance] WHERE [StdID] = '" + txtStdID.Text + "'";
                SqlCommand cmd = new SqlCommand(sqlQuery, con);
                cmd.ExecuteNonQuery();
                con.Close();
                ClearAll();
                LoadData();
            }
            else
            {
                MessageBox.Show("Record not Exist!!!!");
            }
        }
        
        
    }
}
