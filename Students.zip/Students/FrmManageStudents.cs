﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Students
{
    public partial class FrmManageStudents : Form
    {
        public FrmManageStudents()
        {
            InitializeComponent();
        }
        public void Clear()
        {
            txtID.Clear();
            txtSName.Clear();
            txtFName.Clear();
            txtFCNIC.Clear();
            txtAddress.Clear();
            txtCellNo.Clear();
            txtYear.Clear();
            cboDept.Text = "";
            txtSec.Clear();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        public void LoadData()
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=SDM;Integrated Security=True");
            SqlDataAdapter sda = new SqlDataAdapter("SelectStudent", con);
            sda.SelectCommand.CommandType = CommandType.StoredProcedure;

            DataSet ds = new DataSet();
            sda.Fill(ds, "a");
            DGVStudent.DataSource = ds.Tables["a"];
        }

        private void FrmManageStudents_Load(object sender, EventArgs e)
        {
            LoadData();
        }
        public void Display()
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=SDM;Integrated Security=True");
            DataTable dt = new DataTable();
            if (txtSearchID.Text.Length > 0)
            {
                SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM students WHERE SID LIKE '"+txtSearchID.Text+"%'", con);
                sda.Fill(dt);
            }
            else if (txtSearchName.Text.Length > 0)
            {
                SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM students WHERE StudentName LIKE '" + txtSearchName.Text + "%'", con);
                sda.Fill(dt);
            }
            DGVStudent.DataSource = dt;
        }

        private void txtSearchID_TextChanged(object sender, EventArgs e)
        {
            txtSearchName.Text = "";
            if (txtSearchID.Text.Length > 0)
            {
                Display();
            }
            else
            {
                LoadData();
            }

        }

        private void txtSearchName_TextChanged(object sender, EventArgs e)
        {
            txtSearchID.Text = "";
            if (txtSearchName.Text.Length > 0)
            {
                Display();
            }
            else
            {
                LoadData();
            }
        }

        private void DGVStudent_MouseClick(object sender, MouseEventArgs e)
        {
            txtID.Text = DGVStudent.SelectedRows[0].Cells[0].Value.ToString();
            txtSName.Text = DGVStudent.SelectedRows[0].Cells[1].Value.ToString();
            txtFName.Text = DGVStudent.SelectedRows[0].Cells[2].Value.ToString();
            txtFCNIC.Text = DGVStudent.SelectedRows[0].Cells[3].Value.ToString();
            txtAddress.Text = DGVStudent.SelectedRows[0].Cells[4].Value.ToString();
            txtCellNo.Text = DGVStudent.SelectedRows[0].Cells[5].Value.ToString();
            txtYear.Text = DGVStudent.SelectedRows[0].Cells[6].Value.ToString();
            cboDept.Text = DGVStudent.SelectedRows[0].Cells[7].Value.ToString();
            txtSec.Text = DGVStudent.SelectedRows[0].Cells[8].Value.ToString();
            txtAdmDate.Text = DGVStudent.SelectedRows[0].Cells[9].Value.ToString();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=SDM;Integrated Security=True");
            con.Open();
            var sqlQuery = "";
            if (IfStudentExist(con, txtID.Text))
            {
                sqlQuery = @"UPDATE [Students] SET SID = '" + txtID.Text + "',StudentName='" + txtSName.Text + "',FatherName='" + txtFName.Text + "',FatherCNIC='" + txtFCNIC.Text + "',Address='" + txtAddress.Text + "',Cell='" + txtCellNo.Text + "',Year='" + txtYear.Text + "',Department='" + cboDept.Text + "',Section='" + txtSec.Text + "',AdmDate='" + txtAdmDate.Text + "'WHERE [SID] = '" + txtID.Text + "'";
            }
            else 
            { }
            
            SqlCommand cmd = new SqlCommand(sqlQuery, con);
            cmd.ExecuteNonQuery();
            con.Close();
            Clear();
            LoadData();

        }
        private bool IfStudentExist(SqlConnection con, string StudentID)
        {
            SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM [dbo].[Students] WHERE [SID] = '" + StudentID + "'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
                return true;
            else
                return false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=SDM;Integrated Security=True");
            con.Open();
            var sqlQuery = "";
            if (IfStudentExist(con, txtID.Text))
            {
                sqlQuery = @"DELETE FROM [Students] WHERE [SID] = '" + txtID.Text + "'";
                SqlCommand cmd = new SqlCommand(sqlQuery, con);
                cmd.ExecuteNonQuery();
                con.Close();
                Clear();
                LoadData();
            }
            else
            {
                MessageBox.Show("Record not Exist!!!!");
            }
        }

    }
}
