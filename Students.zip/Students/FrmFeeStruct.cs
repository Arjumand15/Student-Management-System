﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Students
{
    public partial class FrmFeeStruct : Form
    {
        public FrmFeeStruct()
        {
            InitializeComponent();
        }
        public void LoadData()
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=SDM;Integrated Security=True");
            SqlDataAdapter sda = new SqlDataAdapter("ViewFee", con);
            sda.SelectCommand.CommandType = CommandType.StoredProcedure;

            DataSet ds = new DataSet();
            sda.Fill(ds, "a");
            DGVFeeDetail.DataSource = ds.Tables["a"];
        }
        
        private void FrmFeeStruct_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
