﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Students
{
    public partial class FrmExam : Form
    {
        public FrmExam()
        {
            InitializeComponent();
        }
        public void ClearAll()
        {
            txtStID.Clear();
            txtExam.Clear();
            txtYr.Clear();
            txtCp.Clear();
            txtCGPA.Clear();
            txtQPt.Clear();
            txtGrade.Clear();
            txtResult.Clear();
        }
        public void LoadData()
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=SDM;Integrated Security=True");
            SqlDataAdapter sda = new SqlDataAdapter("Exam", con);
            sda.SelectCommand.CommandType = CommandType.StoredProcedure;

            DataSet ds = new DataSet();
            sda.Fill(ds, "a");
            DGVResult.DataSource = ds.Tables["a"];

        }
        private void FrmExam_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnAddMod_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=SDM;Integrated Security=True");
            con.Open();
            var sqlQuery = "";
            if (IfExamExist(con, txtStID.Text))
            {
                sqlQuery = @"UPDATE [ExamDetails] SET [Exam] = '" + txtExam.Text + "',Year = '" + txtYr.Text + "',ClearedPapers = '" +txtCp.Text + "',CGPA='" + txtCGPA.Text + "',QualityPoints = '" + txtQPt.Text + "',Grade = '"+txtGrade.Text+"',Result = '"+txtResult.Text+"'WHERE [StudID] = '" + txtStID.Text + "'";
            }
            else
            {
                sqlQuery = @"INSERT INTO [dbo].[ExamDetails]([StudID],[Exam],[Year],[ClearedPapers],[CGPA],[QualityPoints],[Grade],[Result]) VALUES ('" + txtStID.Text + "','" + txtExam.Text + "','" + txtYr.Text + "','" + txtCp.Text + "','" + txtCGPA.Text + "','" + txtQPt.Text + "','" + txtGrade.Text + "','" + txtResult.Text + "')";
            }

            SqlCommand cmd = new SqlCommand(sqlQuery, con);
            cmd.ExecuteNonQuery();
            con.Close();
            LoadData();
            ClearAll();
        }
        private bool IfExamExist(SqlConnection con, string StdID)
        {
            SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM [dbo].[ExamDetails] WHERE [StudID] = '" + StdID + "'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
                return true;
            else
                return false;
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=SDM;Integrated Security=True");
            con.Open();
            var sqlQuery = "";
            if (IfExamExist(con, txtStID.Text))
            {
                sqlQuery = @"DELETE FROM [ExamSetails] WHERE [StudID] = '" + txtStID.Text + "'";
                SqlCommand cmd = new SqlCommand(sqlQuery, con);
                cmd.ExecuteNonQuery();
                con.Close();
                ClearAll();
                LoadData();
            }
            else
            {
                MessageBox.Show("Record not Exist!!!!");
            }
        }

        private void DGVResult_MouseClick(object sender, MouseEventArgs e)
        {
            txtStID.Text = DGVResult.SelectedRows[0].Cells[0].Value.ToString();
            txtExam.Text = DGVResult.SelectedRows[0].Cells[1].Value.ToString();
            txtYr.Text = DGVResult.SelectedRows[0].Cells[2].Value.ToString();
            txtCp.Text = DGVResult.SelectedRows[0].Cells[3].Value.ToString();
            txtCGPA.Text = DGVResult.SelectedRows[0].Cells[4].Value.ToString();
            txtQPt.Text = DGVResult.SelectedRows[0].Cells[5].Value.ToString();
            txtGrade.Text = DGVResult.SelectedRows[0].Cells[6].Value.ToString();
            txtResult.Text = DGVResult.SelectedRows[0].Cells[7].Value.ToString();
        }

        
    }
}
