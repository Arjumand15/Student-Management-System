﻿namespace Students
{
    partial class FrmFaculty
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmFaculty));
            this.txtTGen = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtTName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtTID = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtTDesig = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtTSal = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtCTAssign = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.DGVFaculty = new System.Windows.Forms.DataGridView();
            this.txtTeacherName = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtTeacherID = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnDel = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.DGVFaculty)).BeginInit();
            this.SuspendLayout();
            // 
            // txtTGen
            // 
            this.txtTGen.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.txtTGen.Location = new System.Drawing.Point(135, 104);
            this.txtTGen.Name = "txtTGen";
            this.txtTGen.Size = new System.Drawing.Size(148, 23);
            this.txtTGen.TabIndex = 15;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label5.Location = new System.Drawing.Point(73, 107);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 17);
            this.label5.TabIndex = 14;
            this.label5.Text = "Gender";
            // 
            // txtTName
            // 
            this.txtTName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.txtTName.Location = new System.Drawing.Point(135, 62);
            this.txtTName.Name = "txtTName";
            this.txtTName.Size = new System.Drawing.Size(148, 23);
            this.txtTName.TabIndex = 13;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label2.Location = new System.Drawing.Point(27, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 17);
            this.label2.TabIndex = 12;
            this.label2.Text = "Teacher Name";
            // 
            // txtTID
            // 
            this.txtTID.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.txtTID.Location = new System.Drawing.Point(135, 23);
            this.txtTID.Name = "txtTID";
            this.txtTID.Size = new System.Drawing.Size(148, 23);
            this.txtTID.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label1.Location = new System.Drawing.Point(51, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 17);
            this.label1.TabIndex = 10;
            this.label1.Text = "Teacher ID";
            // 
            // txtTDesig
            // 
            this.txtTDesig.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.txtTDesig.Location = new System.Drawing.Point(379, 101);
            this.txtTDesig.Name = "txtTDesig";
            this.txtTDesig.Size = new System.Drawing.Size(148, 23);
            this.txtTDesig.TabIndex = 21;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label3.Location = new System.Drawing.Point(293, 104);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 17);
            this.label3.TabIndex = 20;
            this.label3.Text = "Designation";
            // 
            // txtTSal
            // 
            this.txtTSal.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.txtTSal.Location = new System.Drawing.Point(376, 62);
            this.txtTSal.Name = "txtTSal";
            this.txtTSal.Size = new System.Drawing.Size(148, 23);
            this.txtTSal.TabIndex = 19;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label4.Location = new System.Drawing.Point(320, 62);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 17);
            this.label4.TabIndex = 18;
            this.label4.Text = "Salary";
            // 
            // txtCTAssign
            // 
            this.txtCTAssign.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.txtCTAssign.Location = new System.Drawing.Point(376, 23);
            this.txtCTAssign.Name = "txtCTAssign";
            this.txtCTAssign.Size = new System.Drawing.Size(148, 23);
            this.txtCTAssign.TabIndex = 17;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label6.Location = new System.Drawing.Point(303, 23);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(70, 17);
            this.label6.TabIndex = 16;
            this.label6.Text = "Course ID";
            // 
            // DGVFaculty
            // 
            this.DGVFaculty.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGVFaculty.Location = new System.Drawing.Point(12, 241);
            this.DGVFaculty.Name = "DGVFaculty";
            this.DGVFaculty.Size = new System.Drawing.Size(529, 150);
            this.DGVFaculty.TabIndex = 22;
            this.DGVFaculty.MouseClick += new System.Windows.Forms.MouseEventHandler(this.DGVFaculty_MouseClick);
            // 
            // txtTeacherName
            // 
            this.txtTeacherName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.txtTeacherName.Location = new System.Drawing.Point(376, 212);
            this.txtTeacherName.Name = "txtTeacherName";
            this.txtTeacherName.Size = new System.Drawing.Size(148, 23);
            this.txtTeacherName.TabIndex = 27;
            this.txtTeacherName.TextChanged += new System.EventHandler(this.txtTeacherName_TextChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label8.Location = new System.Drawing.Point(271, 215);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(102, 17);
            this.label8.TabIndex = 26;
            this.label8.Text = "Teacher Name";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label7.Location = new System.Drawing.Point(26, 182);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(88, 20);
            this.label7.TabIndex = 25;
            this.label7.Text = "SEARCH:";
            // 
            // txtTeacherID
            // 
            this.txtTeacherID.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.txtTeacherID.Location = new System.Drawing.Point(111, 209);
            this.txtTeacherID.Name = "txtTeacherID";
            this.txtTeacherID.Size = new System.Drawing.Size(137, 23);
            this.txtTeacherID.TabIndex = 24;
            this.txtTeacherID.TextChanged += new System.EventHandler(this.txtTeacherID_TextChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label9.Location = new System.Drawing.Point(27, 212);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(78, 17);
            this.label9.TabIndex = 23;
            this.label9.Text = "Teacher ID";
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnExit.Location = new System.Drawing.Point(317, 145);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(97, 26);
            this.btnExit.TabIndex = 30;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnDel
            // 
            this.btnDel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnDel.Location = new System.Drawing.Point(214, 145);
            this.btnDel.Name = "btnDel";
            this.btnDel.Size = new System.Drawing.Size(97, 26);
            this.btnDel.TabIndex = 29;
            this.btnDel.Text = "Delete";
            this.btnDel.UseVisualStyleBackColor = true;
            this.btnDel.Click += new System.EventHandler(this.btnDel_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnAdd.Location = new System.Drawing.Point(111, 145);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(97, 26);
            this.btnAdd.TabIndex = 28;
            this.btnAdd.Text = "Add/Modify";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // FrmFaculty
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(546, 398);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnDel);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.txtTeacherName);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtTeacherID);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.DGVFaculty);
            this.Controls.Add(this.txtTDesig);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtTSal);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtCTAssign);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtTGen);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtTName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtTID);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmFaculty";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmFaculty";
            this.Load += new System.EventHandler(this.FrmFaculty_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DGVFaculty)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtTGen;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtTName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtTID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtTDesig;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtTSal;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtCTAssign;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridView DGVFaculty;
        private System.Windows.Forms.TextBox txtTeacherName;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtTeacherID;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnDel;
        private System.Windows.Forms.Button btnAdd;
    }
}