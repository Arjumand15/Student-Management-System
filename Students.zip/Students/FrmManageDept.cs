﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Students
{
    public partial class FrmManageDept : Form
    {
        public FrmManageDept()
        {
            InitializeComponent();
        }
        public void ClearAll()
        {
            txtDID.Clear();
            txtDName.Clear();
        }

        public void LoadData()
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=SDM;Integrated Security=True");
            SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM [dbo].[Department]",con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            DGVDept.Rows.Clear();
            foreach (DataRow item in dt.Rows)
            {
                int n = DGVDept.Rows.Add();
                DGVDept.Rows[n].Cells[0].Value = item["DeptID"].ToString();
                DGVDept.Rows[n].Cells[1].Value = item["DeptName"].ToString();
            }

        }


        private void FrmManageDept_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void btnAddUpdate_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=SDM;Integrated Security=True");
            con.Open();
            var sqlQuery = "";
            if (IfDeptExist(con, txtDID.Text))
            {
                sqlQuery = @"UPDATE [Department] SET [DeptName] = '" + txtDName.Text + "'WHERE [DeptID] = '" + txtDID.Text + "'";
            }
            else 
            {
                sqlQuery = @"INSERT INTO [dbo].[department]([DeptID],[DeptName]) VALUES ('"+txtDID.Text+"','"+txtDName.Text+"')";
            }
            
            SqlCommand cmd = new SqlCommand(sqlQuery, con);
            cmd.ExecuteNonQuery();
            con.Close();
            LoadData();
            ClearAll();
        }

        private bool IfDeptExist(SqlConnection con, string DeptID)
        {
            SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM [dbo].[Department] WHERE [DeptID] = '" + DeptID + "'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
                return true;
            else
                return false;

        }


        private void DGVDept_DoubleClick(object sender, EventArgs e)
        {
            
        }

       

        
        private void btnDelete_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=SDM;Integrated Security=True");
            con.Open();
            var sqlQuery = "";
            if (IfDeptExist(con, txtDID.Text))
            {
                sqlQuery = @"DELETE FROM [Department] WHERE [DeptID] = '" + txtDID.Text + "'";
                SqlCommand cmd = new SqlCommand(sqlQuery, con);
                cmd.ExecuteNonQuery();
                con.Close();
                ClearAll();
                LoadData();
            }
            else
            {
                MessageBox.Show("Record not Exist!!!!");
            }
        }

        private void DGVDept_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void DGVDept_MouseClick(object sender, MouseEventArgs e)
        {
            txtDID.Text = DGVDept.SelectedRows[0].Cells[0].Value.ToString();
            txtDName.Text = DGVDept.SelectedRows[0].Cells[1].Value.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        
    }
}
