﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Students
{
    public partial class FrmStart : Form
    {

        int progress = 0;

        public FrmStart()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            progress += 1;
            if (progress >= 100)
            {
                timer1.Enabled = false;
                timer1.Stop();
                this.Hide();
                FrmLogin fl = new FrmLogin();
                fl.Show();
            }
            progressBar1.Value = progress;

        }

        private void FrmStart_Load(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            timer1.Interval = 50;

        }
    }
}
