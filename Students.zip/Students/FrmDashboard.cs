﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Students
{
    public partial class FrmDashboard : Form
    {
        public FrmDashboard()
        {
            InitializeComponent();
        }

        private void addToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmAddStudent fad = new FrmAddStudent();
            fad.Show();
        }

        private void manageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmManageStudents fms = new FrmManageStudents();
            fms.Show();
        }

        private void modifyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmManageDept fmd = new FrmManageDept();
            fmd.Show();
        }

        private void addModifyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmCourses fc = new FrmCourses();
            fc.Show();
        }

        private void addModifyToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            FrmFaculty ff = new FrmFaculty();
            ff.Show();
        }

        private void manageRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmFinance ffi = new FrmFinance();
            ffi.Show();
        }

        private void feeStructureToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmFeeStruct ffs = new FrmFeeStruct();
            ffs.Show();
        }

        private void addModifyToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            FrmExam fe = new FrmExam();
            fe.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
