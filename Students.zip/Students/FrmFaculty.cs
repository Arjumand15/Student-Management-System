﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Students
{
    public partial class FrmFaculty : Form
    {
        public FrmFaculty()
        {
            InitializeComponent();
        }

        public void ClearAll()
        {
            txtTID.Clear();
            txtTName.Clear();
            txtTGen.Clear();
            txtTSal.Clear();
            txtTDesig.Clear();
            txtCTAssign.Clear();
        }
        public void LoadData()
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=SDM;Integrated Security=True");
            SqlDataAdapter sda = new SqlDataAdapter("SelectTeachers", con);
            sda.SelectCommand.CommandType = CommandType.StoredProcedure;

            DataSet ds = new DataSet();
            sda.Fill(ds, "a");
            DGVFaculty.DataSource = ds.Tables["a"];

        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=SDM;Integrated Security=True");
            con.Open();
            var sqlQuery = "";
            if (IfTeacherExist(con, txtTID.Text))
            {
                sqlQuery = @"UPDATE [Faculty] SET [TName] = '" + txtTName.Text + "',Gender = '" + txtTGen.Text + "',Salary = '" + txtTSal.Text + "',Designation='" + txtTDesig.Text +"',CourseAssigned = '"+txtCTAssign.Text+ "'WHERE [TID] = '" + txtTID.Text + "'";
            }
            else
            {
                sqlQuery = @"INSERT INTO [dbo].[Faculty]([TID],[TName],[Gender],[Salary],[Designation],[CourseAssigned]) VALUES ('" + txtTID.Text + "','" + txtTName.Text + "','" + txtTGen.Text + "','" + txtTSal.Text + "','" + txtTDesig.Text + "','"+txtCTAssign.Text+"')";
            }

            SqlCommand cmd = new SqlCommand(sqlQuery, con);
            cmd.ExecuteNonQuery();
            con.Close();
            LoadData();
            ClearAll();
        }

        private void FrmFaculty_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private bool IfTeacherExist(SqlConnection con, string TeaID)
        {
            SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM [dbo].[Faculty] WHERE [TID] = '" + TeaID + "'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
                return true;
            else
                return false;
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=SDM;Integrated Security=True");
            con.Open();
            var sqlQuery = "";
            if (IfTeacherExist(con, txtTID.Text))
            {
                sqlQuery = @"DELETE FROM [Faculty] WHERE [TID] = '" + txtTID.Text + "'";
                SqlCommand cmd = new SqlCommand(sqlQuery, con);
                cmd.ExecuteNonQuery();
                con.Close();
                ClearAll();
                LoadData();
            }
            else
            {
                MessageBox.Show("Record not Exist!!!!");
            }
        }

        private void DGVFaculty_MouseClick(object sender, MouseEventArgs e)
        {
            txtTID.Text = DGVFaculty.SelectedRows[0].Cells[0].Value.ToString();
            txtTName.Text = DGVFaculty.SelectedRows[0].Cells[1].Value.ToString();
            txtTGen.Text = DGVFaculty.SelectedRows[0].Cells[2].Value.ToString();
            txtTSal.Text = DGVFaculty.SelectedRows[0].Cells[3].Value.ToString();
            txtTDesig.Text = DGVFaculty.SelectedRows[0].Cells[4].Value.ToString();
            txtCTAssign.Text = DGVFaculty.SelectedRows[0].Cells[5].Value.ToString();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public void Display()
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=SDM;Integrated Security=True");
            DataTable dt = new DataTable();
            if (txtTeacherID.Text.Length > 0)
            {
                SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM Faculty WHERE TID LIKE '" + txtTeacherID.Text + "%'", con);
                sda.Fill(dt);
            }
            else if (txtTeacherName.Text.Length > 0)
            {
                SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM Faculty WHERE TName LIKE '" + txtTeacherName.Text + "%'", con);
                sda.Fill(dt);
            }
            DGVFaculty.DataSource = dt;
        }
        

        private void txtTeacherID_TextChanged(object sender, EventArgs e)
        {
             txtTeacherName.Text= "";
             if (txtTeacherID.Text.Length > 0)
            {
                Display();
            }
            else
            {
                LoadData();
            }
        }

        private void txtTeacherName_TextChanged(object sender, EventArgs e)
        {
            txtTeacherID.Text = "";
            if (txtTeacherName.Text.Length > 0)
            {
                Display();
            }
            else
            {
                LoadData();
            }
        }

    }
}
