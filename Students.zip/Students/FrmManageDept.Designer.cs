﻿namespace Students
{
    partial class FrmManageDept
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmManageDept));
            this.DGVDept = new System.Windows.Forms.DataGridView();
            this.DeptID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Dept = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.txtDID = new System.Windows.Forms.TextBox();
            this.btnDelete = new System.Windows.Forms.Button();
            this.txtDName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnAddUpdate = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.DGVDept)).BeginInit();
            this.SuspendLayout();
            // 
            // DGVDept
            // 
            this.DGVDept.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGVDept.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.DeptID,
            this.Dept});
            this.DGVDept.Location = new System.Drawing.Point(12, 255);
            this.DGVDept.Name = "DGVDept";
            this.DGVDept.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DGVDept.Size = new System.Drawing.Size(246, 156);
            this.DGVDept.TabIndex = 0;
            this.DGVDept.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGVDept_CellContentClick);
            this.DGVDept.DoubleClick += new System.EventHandler(this.DGVDept_DoubleClick);
            this.DGVDept.MouseClick += new System.Windows.Forms.MouseEventHandler(this.DGVDept_MouseClick);
            // 
            // DeptID
            // 
            this.DeptID.HeaderText = "Department ID";
            this.DeptID.Name = "DeptID";
            // 
            // Dept
            // 
            this.Dept.HeaderText = "Department";
            this.Dept.Name = "Dept";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label1.Location = new System.Drawing.Point(20, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Department ID";
            // 
            // txtDID
            // 
            this.txtDID.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.txtDID.Location = new System.Drawing.Point(23, 41);
            this.txtDID.Name = "txtDID";
            this.txtDID.Size = new System.Drawing.Size(181, 23);
            this.txtDID.TabIndex = 2;
            // 
            // btnDelete
            // 
            this.btnDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnDelete.Location = new System.Drawing.Point(131, 148);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(92, 23);
            this.btnDelete.TabIndex = 3;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // txtDName
            // 
            this.txtDName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.txtDName.Location = new System.Drawing.Point(23, 108);
            this.txtDName.Name = "txtDName";
            this.txtDName.Size = new System.Drawing.Size(181, 23);
            this.txtDName.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label2.Location = new System.Drawing.Point(20, 91);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(123, 17);
            this.label2.TabIndex = 4;
            this.label2.Text = "Department Name";
            // 
            // btnAddUpdate
            // 
            this.btnAddUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnAddUpdate.Location = new System.Drawing.Point(23, 148);
            this.btnAddUpdate.Name = "btnAddUpdate";
            this.btnAddUpdate.Size = new System.Drawing.Size(92, 23);
            this.btnAddUpdate.TabIndex = 6;
            this.btnAddUpdate.Text = "Add/Update";
            this.btnAddUpdate.UseVisualStyleBackColor = true;
            this.btnAddUpdate.Click += new System.EventHandler(this.btnAddUpdate_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.button1.Location = new System.Drawing.Point(73, 194);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(92, 23);
            this.button1.TabIndex = 7;
            this.button1.Text = "Exit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // FrmManageDept
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(270, 422);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnAddUpdate);
            this.Controls.Add(this.txtDName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.txtDID);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.DGVDept);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmManageDept";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmManageDept";
            this.Load += new System.EventHandler(this.FrmManageDept_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DGVDept)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView DGVDept;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtDID;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.TextBox txtDName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnAddUpdate;
        private System.Windows.Forms.DataGridViewTextBoxColumn DeptID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Dept;
        private System.Windows.Forms.Button button1;
    }
}